let m=new Map()
    class product{
    pid=0;
    pname='';
    pprice=0;
    pdesc='';
    constructor(pid,pname,pprice,pdesc)
    {
        this.pid=pid;
        this.pname=pname;
        this.pprice=pprice;
        this.pdesc=pdesc;
    }
    printAllData(){
        document.write(this.pid+" "+this.pname+" "+this.pprice+" "+this.pdesc)
    }
}
function add(){
    let p1=new Product(1002,"Mobile",19812,"Mobile")
    let p2=new Product(1003,"Rice",66,"Grocery")
    let p3=new Product(1001,"Pen",32,"Stationary")
    let p4=new Product(1000,"Pencil",8,"Stationary")
    m.set(1002,p1)
    m.set(1003,p2)
    m.set(1001,p3)
    m.set(1000,p4)
    alert('added successfully')
}
function showAll(){
    let pa=Array.from(m.values())
    pa.sort((a,b)=>{
        if(a.price>b.price)
        return 1;
        else if(a.price<b.price)
        return -1;
        else return 0;
    })
    for (let a of pa){
        document.write(a.pname+" "+a.pprice+" "+a.pdesc+"<br>")
    }
}
function deleteP(pid){
    if(m.has(pid)){
        m.deleteP(pid);
        alert("deleted..")
    }
    else{
        alert("product not found..")
    }

}


