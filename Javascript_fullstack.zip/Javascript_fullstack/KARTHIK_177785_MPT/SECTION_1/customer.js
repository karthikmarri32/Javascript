function display(){

let state=document.getElementById("s").value
if(state=="ka"){
    alert("postal code:560000 ,store location:Bangalore")
}else if(state=="mas"){
    alert("postal code:600000 ,store location:Chennai")
}else if(state=="kl"){
    alert("postal code:680000 ,store location:Thiruvananthapuram")
}else{
    alert("postal code:500000 ,store location:Hyderabad")
}
}
function displayData(){
    let name=document.getElementById("n").value
    let adr=document.getElementById("adr").value
    let st=document.getElementById("st").value
    let ph=document.getElementById("ph").value
    let mail=document.getElementById("mail").value
    let con=document.getElementById("con").value
    let date=document.getElementById("date").value
    let des=document.getElementById("des").value
    alert("Name:"+name+"<br>"+"Address:"+adr+"<br>"+"State:"+st+"<br>"+"Phone:"+ph+"<br>"+"Email:"+mail+"<br>"+"Way of contact:"+con+"<br>"+"Date:"+date+"<br>"+"describe the incident"+des)
}