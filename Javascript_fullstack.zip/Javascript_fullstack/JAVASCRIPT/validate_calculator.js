function validate(){
    let x=document.getElementById('num1').value;
    let y=document.getElementById('num2').value;
    if (x==''&&y==''){
        alert('field should not be empty')
    } else {
        let a=parseInt(x)
        let b=parseInt(y)
        let pr=window.open("","","width=400,height=400");
        pr.document.write(
            "<table><tr><th>Operation</th><th>Num1</th><th>Num2</th><th>Result</th></tr>"+
            "<tr><td>Sum</td><td>"+a+"</td><td>"+b+"</td><td>"+(a+b)+"</td></tr></table>"
        )
    }
}
validate();