class Customer{
    id=0;
    name='';
    city='';
    constructor(id,name,city){
        this.id=id;
        this.name=name;
        this.city=city;
    }
    printDetails(){
        document.write(this.id+" "+this.name+" "+this.city);
    }
}

let c=new Customer(777,"NAG","HYD");
c.printDetails();