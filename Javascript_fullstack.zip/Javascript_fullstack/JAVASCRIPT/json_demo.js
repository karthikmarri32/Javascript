let products=[];
function add(n){
    for (let i=1;i<=n;i++){
        let id=prompt('enter id');
        let name=prompt('enter name');
        let city=prompt('enter city');
        let p={id:id,name:name,city:city};
        let jp=JSON.stringify(p);
        products.push(jp);
    }
}

function showAll(){
    for (let pr of products){
        let p=JSON.parse(pr);
        document.write("<br>Id:"+p.id+"Name:"+p.name+"City:"+p.city);
    }
}