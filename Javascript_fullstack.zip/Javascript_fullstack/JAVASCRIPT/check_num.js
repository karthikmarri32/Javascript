function checkNum(n){
    if(n>=0){
        document.write("positive");
    } else{
        document.write("nagative");
    }
}
checkNum(9);

document.write("<br>")
function checkEvenOdd(n){
    if(n%2==0){
        document.write("Even");
    } else{
        document.write("Odd");
    }
}
checkEvenOdd(8);

document.write("<br>")
function checkMultipleOfTen(n){
    if(n%10==0){
        document.write("multiple");
    } else{
        document.write("not multiple");
    }
}
checkMultipleOfTen(55);

document.write("<br>")
function findGrade(marks){
    if(marks>=90&&marks<=100){
        document.write("Grade A");
    }
    else if(marks<90&&marks>=80){
        document.write("Grade B");
    }
    else if(marks<80&&marks>=60){
        document.write("Grade C");
    }
    else{
        document.write("Fail");
    }
    document.write("Result");
    }
    findGrade(75);

    document.write("<br>")
    function FizzBuzz(num){
        if(num%3==0&&num%5==0){
            document.write("FizzBuzz");
        }
        else if(num%5==0){
            document.write("Buzz");
        }
        else if(num%3==0){
            document.write("Fizz");
        }
        else{
            document.write("num");
        }
    }
    FizzBuzz(30);
    
