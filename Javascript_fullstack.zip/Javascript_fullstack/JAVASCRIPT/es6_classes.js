class Person{
    age=0;
    name='';
    constructor(name,age){
        this.name=name;
        this.age=age;
    }
    display(){
        document.write(this.name+" "+this.age);
    }
}

// // instance of the class
// let p=new Person();
// p.age=21;
// p.name='karthik';
// p.display();

let p=new Person("NAG",21);
p.display();