function dateDemo(){
    let d=new Date();
    let hrs=d.getHours();
    let m=d.getMinutes();
    let s=d.getSeconds();
    document.getElementById("timer").innerText=hrs+":"+m+":"+s
}
setInterval(dateDemo,1000)
    // document.write(d+"<br>");
    // document.write("Year:"+d.getFullYear()+"<br>");
    // document.write("Month:"+d.getMonth()+"<br>");
    // document.write("Date:"+d.getDate()+"<br>");
    // document.write("Day:"+d.getDay()+"<br>");
    // document.write("Hours:"+d.getHours()+"<br>");
    // document.write("Minutes:"+d.getMinutes()+"<br>");
    // document.write("Seconds:"+d.getSeconds()+"<br>");
// }
// dateDemo();