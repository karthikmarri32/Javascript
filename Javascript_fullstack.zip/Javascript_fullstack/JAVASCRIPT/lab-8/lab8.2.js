function productDetails(){
    let t=document.getElementById('category').value;
    let electronics=['television','laptop','phone']
    let grocery=['soap','powder']
    let c=document.getElementById('course');
    if(t=='el'){
        c.options.length=0;
        for(let i=0; i<electronics.length;i++){
            let opt=document.createElement('option');
            opt.text=electronics[i];
            opt.value=electronics[i];
            c.add(opt);
        }
    }else{
        c.options.length=0;
        for(let i=0; i<grocery.length;i++){
            let opt=document.createElement('option');
            opt.text=grocery[i];
            opt.value=grocery[i];
            c.add(opt);
        }
    }
}

function calculate(){
    let c=document.getElementById('course').value;
    let n=document.getElementById('qty').value;
    if (c =='television'){
            document.getElementById('tp').value=(n*500);
    }
    if (c =='laptop'){
        document.getElementById('tp').value=(n*500);
    }
    if (c =='phone'){
        document.getElementById('tp').value=(n*500);
    }
    if (c =='soap'){
        document.getElementById('tp').value=(n*500);
    }
    if (c =='powder'){
        document.getElementById('tp').value=(n*500);
    }
}