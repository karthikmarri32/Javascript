function compute(eve){
    eve.preventDefault();
    let a=document.getElementById('lamt').value;
    let b=document.getElementById('roi').value;
    let c=document.getElementById('period').value;
    if(a >= 100000 && a<=1500000){
        loanAmount=parseInt(a)
    }else{
        alert("Invalid Amount")
    }
    // let r=document.getElementById('roi').value;
    let roi=0;
    if (c>=7 && c<=15){
       roi = c;
    }else{
        alert("number should be>0");
    }
    // let p=document.getElementById('period').value;
    let monthlyPayment=(loanAmount*b*roi)/100;
    document.getElementById('ip').value = monthlyPayment;
    let totalPayment=(monthlyPayment+loanAmount)/12;
    document.getElementById('mp').value = totalPayment;
    document.getElementById('tp').value = loanAmount+monthlyPayment;
}