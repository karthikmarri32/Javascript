function stringAPI(){
    let city="hyderabad";
    document.write("uppercase"+city.toUpperCase()+"<br>");
    document.write("length:"+city.length+"<br>");
    document.write("charAt(2):"+city.charAt(2)+"<br>");
    document.write("indexOf(r):"+city.indexOf('r')+"<br>");
    document.write("substring(2):"+city.substring(2)+"<br>");
    document.write("substring(2,5):"+city.substring(2,5)+"<br>");
    document.write("substr(2,4):"+city.substr(2,4)+"<br>");
}
stringAPI();