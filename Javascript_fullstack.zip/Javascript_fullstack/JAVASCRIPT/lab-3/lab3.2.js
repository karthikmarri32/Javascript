function string(){
    let company="Capgemini";
    document.write("the actual string is:"+company+"<br>");
    document.write("the character to be searched is:"+company.charAt(2)+"<br>");
    document.write("the character found at the index:"+company.indexOf('p'));
}
string();