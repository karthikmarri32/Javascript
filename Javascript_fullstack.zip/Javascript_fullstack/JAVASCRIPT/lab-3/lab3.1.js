function date(){
    let d=new Date();
    document.write(d+"<br>");
    let hrs=d.getHours();
    if(hrs<12){
        document.write("Good Morning");
    }
    else if(hrs>=12&&hrs<=17){
        document.write("Good Afternoon");
    }
    else if (hrs>17){
        document.write("Good Evening");
    }
    else {
        document.write("Good Night");
    }
}
date();