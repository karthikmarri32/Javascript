function str(){
    let company="University at Capgemini";
    document.write("string is:"+company+"<br>");
    document.write("result of str.match('Capgemini'):"+company.match('capgemini')+"<br>");
    document.write("result of str.substr(3,6):"+company.substr(3,6)+"<br>");
    document.write("hello javascripters!"+"<br>");
    document.write("HELLO JAVASCRIPTERS!"+"<br>");
}
str();