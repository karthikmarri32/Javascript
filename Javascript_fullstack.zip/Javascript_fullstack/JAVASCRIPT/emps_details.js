function Employee(id,name,salary){
    this.id=id;
    this.name=name;
    this.salary=salary;
}
let emps=[];
function add(n){
    for (let i=1;i<=n;i++){
        let id=prompt('enter id');
        let name=prompt('enter name');
        let salary=prompt('enter salary');
        let e=new Employee(id,name,salary);
        emps.push(e);
    }
}



function showAll(){
    for (let e of emps){
        document.write("<br>Id:"+e.id);
        document.write("<br>Name:"+e.name);
        document.write("<br>Salary:"+e.salary);
    }
}