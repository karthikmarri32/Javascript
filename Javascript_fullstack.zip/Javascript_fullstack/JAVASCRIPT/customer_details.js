function Customer(id,name,city){
    this.id=id;
    this.name=name;
    this.city=city;
}
let customers=[];
function add(n){
    for (let i=1;i<=n;i++){
        let id=prompt('enter id');
        let name=prompt('enter name');
        let city=prompt('enter city');
        let e=new Customer(id,name,city);
        customers.push(e);
    }
}



function showAll(){
    for (let e of customers){
        document.write("<br>Id:"+e.id);
        document.write("<br>Name:"+e.name);
        document.write("<br>City:"+e.city);
    }
}