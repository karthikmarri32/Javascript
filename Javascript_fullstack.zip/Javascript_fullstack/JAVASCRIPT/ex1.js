function calculateEMI(eve){
    eve.preventDefault();
    let la=document.getElementById('lamt').value;
    let loanamount=0;
    if (la>=100000 && la<=500000){
        loanamount=parseInt(la);
    }else{
        alert("only numbers");
    }
    let r=document.getElementById('roi').value;
    let roi=0;
    if (r>=1){
       roi=parseInt(r);
    }else{
        alert("number should be>0");
    }
    let p=document.getElementById('period').value;
    let interestAmount=(loanamount*roi*p)/100;
    document.getElementById('iamt').value = interestAmount;
    let monthlyEMI=(loanamount+interestAmount)/12;
    document.getElementById('emi').value =monthlyEMI;
}