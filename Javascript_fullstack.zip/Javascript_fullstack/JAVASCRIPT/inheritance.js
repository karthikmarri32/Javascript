class Person{
    name='';
    age='';
    constructor(name,age){
        this.name=name;
        this.age=age;
    }
}
// class Student extends Person{
//     university='';
//     constructor(name,age,university){
//         super(name,age);
//         this.university=university;
//     }
//     printStudentDetails(){
//         document.write(this.name+" "+this.age+" "+this.university);
//     }
// }

// let s=new Student('karthik',21,'capgemini');
// s.printStudentDetails();


class Employee extends Person{
    salary='';
    constructor(name,age,salary){
        super(name,age);
        this.salary=salary;
    }
    printEmployeeDetails(){
        document.write(this.name+" "+this.age+" "+this.salary);
    }
}

let s=new Employee('karthik',21,'100000');
s.printEmployeeDetails();
