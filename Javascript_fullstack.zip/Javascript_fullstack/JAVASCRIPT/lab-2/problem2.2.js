function ci(){
    let p=1000;
    let roi=10;
    let n=1;
    let ci=(p*Math.pow(1+roi/100),n)-p;
    document.write("----------------------------<br>")
    document.write("*****Compound Interest*****<br>")
    document.write("----------------------------<br>")
    document.write("Principal &nbsp;&nbsp;&nbsp;&nbsp;-"+p+"rs<br>");
    document.write("Rate of Interest &nbsp;&nnsp;-"+roi+"%<br>");
    document.write("Priod &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-"+n+"<br>");   
}
ci();