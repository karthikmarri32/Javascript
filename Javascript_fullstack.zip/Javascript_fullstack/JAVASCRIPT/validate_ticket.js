function validateticket(){
    let x=document.getElementById('num').value;
    let price=120;
    if(x<0 || x>6)
    {
        alert('Enter the correct no of tickets')
    }else{
        // let a=parseInt('n')
        let total = price * x;
        let pr=window.open("","","width=400,height=400");
        // let b=parseInt('pric)
        pr.document.write("your price is:"+total);
    }
}
