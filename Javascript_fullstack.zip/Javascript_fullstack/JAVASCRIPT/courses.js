function showCourses(){
    let t=document.getElementById('tech').value;
    let f_courses=['html','javascript']
    let b_courses=['java','dotnet']
    let c=document.getElementById('course');
    if(t=='fe'){
        c.options.length=0;
        for(let i=0; i<f_courses.length;i++){
            let opt=document.createElement('option');
            opt.text=f_courses[i];
            opt.value=f_courses[i];
            c.add(opt);
        }
    }else{
        c.options.length=0;
        for(let i=0; i<b_courses.length;i++){
            let opt=document.createElement('option');
            opt.text=b_courses[i];
            opt.value=b_courses[i];
            c.add(opt);
    }
    }
}

function calculate(){
    let c=document.getElementById('course').value;
    let n=document.getElementById('ne').value;
    if (c =='html'){
            document.getElementById('total').value=n*500;
    }
}