// alert('HelloWorld')
document.write('Hello World')