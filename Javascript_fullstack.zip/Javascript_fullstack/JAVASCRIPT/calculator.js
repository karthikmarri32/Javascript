function doSum(){
    let a=document.getElementById('fv').value;
    let b=document.getElementById('sv').value;
    alert(parseInt(a)+parseInt(b));
    let pr=window.open("","","width=400,height=400");
    pr.document.write(a+"<br>");
    pr.document.write(b+"<br>");
    }
doSum();

function doSub(){
    let a=document.getElementById('fv').value;
    let b=document.getElementById('sv').value;
    alert(parseInt(a)-parseInt(b));
    let pr=window.open("","","width=500,height=500");
    pr.document.write(a+"<br>");
    pr.document.write(b+"<br>");
    }
doSub();