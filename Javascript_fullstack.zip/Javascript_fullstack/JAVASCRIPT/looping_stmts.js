function print1to10(){
    let i=1;
    while (i<=10){
        document.write("i:"+i+"<br>");
        i++;
    }
}
print1to10();



document.write("-----------------For------------------<br>")
function demoFor1to10(){
    for(let i=1;i<=10;i++){
        document.write("i:"+i+"<br>");   
    }
}
demoFor1to10();



document.write("-----------------For------------------<br>")
function doWhileDemo(){
    let i=1;
    do{
        document.write("i:"+i+"<br>");
        i++;
    }while(i<=10);
}
doWhileDemo();



document.write("-----------------For------------------<br>")
function display(){
    for(let i=1;i<10;i++){
        document.write(i)
    }
}
display();


document.write("-----------------For------------------<br>")
//program to print even numbers from 1 to 10
function evenNum(){
    for(let i=1;i<=10;i++){
        if(i%2==0){
            document.write(i+"<br>")
        }
    }
}
evenNum();

document.write("-----------------For------------------<br>")
//program to print odd numbers from 1 to 10
function oddNum(){
    for(let i=1;i<=10;i++){
        if(i%2!=0){
            document.write(i+"<br>")
        }
    }
}
oddNum();

document.write("-----------------For------------------<br>")
//program to print sum of first 10 numbers
function printsum(){
    let sum=0;
    for(let i=1;i<=10;i++){
        sum=sum+i;
    }
    document.write("result:"+sum)
}
printsum();