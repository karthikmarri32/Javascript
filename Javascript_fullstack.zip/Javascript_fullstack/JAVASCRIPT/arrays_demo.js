function arrayDemo(){
    let skills=['java','pega','angular','javascript','react'];
    for(let a=0;a<skills.length;a++){
        document.write(skills[a]+ "<br>")
    }
}
// arrayDemo();

// document.write("<br>")
// function arrayNum(){
//     let prices=['22.4,44.6,88.6,176.8,352.6'];
//     for(let a=0;a<prices.length;a++){
//         document.write(prices[a]+ "<br>")
//     }
// }
// arrayNum();

let nums=[5,1,7,2,8];
for(let n of nums){
    document.write(n+"<br>")
}
arrayDemo();