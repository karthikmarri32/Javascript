function order(){
    let a=document.getElementById('n1').value;
    let b=document.getElementById('n2').value;
    let c=document.getElementById('n3').value;
    let d=document.getElementById('n4').value;
    let v = document.getElementById("name1").innerHTML;
    let w = document.getElementById("name2").innerHTML;
    let y = document.getElementById("name3").innerHTML;
    let z = document.getElementById("name4").innerHTML;
    let e = document.getElementById("qty1").innerHTML;
    let f = document.getElementById("qty2").innerHTML;
    let g = document.getElementById("qty3").innerHTML;
    let h = document.getElementById("qty4").innerHTML;
    if (a==""&&b==""&&c==""&&d==""){
        alert("no items selected")
    }
    else if(a!=0 && b==0 && c==0 && d==0)
    {
        document.write("<table border = '1'><caption>INVOICE</caption><tr><th>PRODUCT</th><th>QUANTITY</th><th>PRICE</th><th>TOTAL</th>"+"<tr><td>" + v + "</td><td>" + a + "</td><td>" + e + "</td><td>" + a*e +"</td></tr></table>");
    }
    else if(a!=0 && b!=0 && c==0 && d==0)
    {
        document.write("<table border = '1'><caption>INVOICE</caption><tr><th>PRODUCT</th><th>QUANTITY</th><th>PRICE</th><th>TOTAL</th>"+"<tr><td>" + v + "</td><td>" + a + "</td><td>" + e + "</td><td>" + a*e +"</td></tr>"+"<tr><td>" + w + "</td><td>" + b + "</td><td>" + f + "</td><td>" + b*f +"</td></tr></table>");
    }
    else if(a!=0 && b!=0 && c!=0 && d==0)
    {
        document.write("<table border = '1'><caption>INVOICE</caption><tr><th>PRODUCT</th><th>QUANTITY</th><th>PRICE</th><th>TOTAL</th>"+"<tr><td>" + v + "</td><td>" + a + "</td><td>" + e + "</td><td>" + a*e +"</td></tr>"+"<tr><td>" + w + "</td><td>" + b + "</td><td>" + f + "</td><td>" + b*f +"</td></tr>"+"<tr><td>" + y + "</td><td>" + c + "</td><td>" + g + "</td><td>" + c*g +"</td></tr></table>");
    }
    else if(a!=0 && b!=0 && c!=0 && d!=0)
    {
        document.write("<table border = '1'><caption>INVOICE</caption><tr><th>PRODUCT</th><th>QUANTITY</th><th>PRICE</th><th>TOTAL</th>"+"<tr><td>" + v + "</td><td>" + a + "</td><td>" + e + "</td><td>" + a*e +"</td></tr>"+"<tr><td>" + w + "</td><td>" + b + "</td><td>" + f + "</td><td>" + b*f +"</td></tr>"+"<tr><td>" + y + "</td><td>" + c + "</td><td>" + g + "</td><td>" + c*g +"</td></tr>"+"<tr><td>" + z + "</td><td>" + d + "</td><td>" + h + "</td><td>" + d*h +"</td></tr></table>");
    }
    
}