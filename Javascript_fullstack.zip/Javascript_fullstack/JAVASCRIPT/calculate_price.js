function show(eve)
{
    eve.preventDefault();
    let x=document.getElementById('n').value;
    let y=document.getElementById('p').value;
    if(x!=0 && y!='')
    {
    if(x>=1&&x<=6)
    {
        if(y!=''){
            let p=parseInt(y);
            document.getElementById('tamt').value=x*y;
        }
    
else{
        alert('enter the valid input');
    }   
}
}
else 
alert('enter invalid input');   
}