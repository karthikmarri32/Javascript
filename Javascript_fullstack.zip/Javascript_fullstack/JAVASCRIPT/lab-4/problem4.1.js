function employeeList(){
    document.write("<b>List of Employees</b>","<br>")
    document.write("-------------------------","<br>")
    let skills=['Tove','Hege','Stale','kai Jim','Borge','undefined'];
    for(let a=0;a<skills.length;a++){
            document.write(a+1 +"." +" ")
            document.write(skills[a],"<br>")
        }
    }
    employeeList();