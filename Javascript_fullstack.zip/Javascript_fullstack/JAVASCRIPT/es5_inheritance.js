let person={
    name:'',
    age:0,
    display(){
        document.write(this.name+" "+this.age);
    }
}

let student={
    college_name:'',
    display(){
        document.write(this.name+" "+this.age+" "+this.college_name);
    }
}

student.__proto__=person;
student.name='karthik';
student.age=21;
student.college_name='kl university';
student.display();

let employee={
    name:'',
    age:0,
    display(){
        document.write(this.name+" "+this.age);
    }
}

let empdata={
    salary:'',
    display(){
        document.write(this.name+" "+this.age+" "+this.salary);
    }
}

empdata.__proto__=employee;
empdata.name='karthik';
empdata.age=21;
empdata.salary='100000';
empdata.display();
