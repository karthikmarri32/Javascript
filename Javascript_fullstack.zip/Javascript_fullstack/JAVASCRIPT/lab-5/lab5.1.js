function display(){
    let width=document.getElementById('w').value;
    let height=document.getElementById('h').value;
    let left=document.getElementById('l').value;
    let top=document.getElementById('t').value;
    let pr=window.open("","","width="+width+",height="+height+", left="+left+", top="+top+"");
    pr.document.write("The window is opened on clicking of the New Window button")
}

