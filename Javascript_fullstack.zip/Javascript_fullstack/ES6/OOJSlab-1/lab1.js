function product(id,name,price,description){
    this.id=id;
    this.name=name;
    this.price=price;
    this.description=description;
}
let products=[];
function add(n){
    for (let i=1;i<=n;i++){
        let id=prompt('enter id');
        let name=prompt('enter name');
        let price=prompt('enter price');
        let description=prompt('enter description');
        let d=new product(id,name,price,description);
        products.push(d)
        }
}

function showAll(){
    for (let d of products){
        document.write("<br>Id:"+d.id);
        document.write("<br>Name:"+d.name);
        document.write("<br>Price:"+d.price);
        document.write("<br>Description:"+d.description);
        console.log(d.id);
        console.log(d.name);
        console.log(d.price);
        console.log(d.description);
    }
}