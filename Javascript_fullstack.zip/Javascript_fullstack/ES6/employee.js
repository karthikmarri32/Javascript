class Employee extends Person{
    salary=0;
    constructor(name,age,salary){
        super(name,age);
        this.salary=salary;
    }
    printAll(){
        document.write("<br>"+this.name+" "+this.age+" "+this.salary);
    }
}
let e1=new Employee('Karthik',21,100000);
e1.printAll();
