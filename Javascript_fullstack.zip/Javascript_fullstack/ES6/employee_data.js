let s=new Set();
function addDetails(n){
    for (let i=1;i<=n;i++){
        let id=prompt('enter id');
        let name=prompt('enter name');
        let salary=prompt('enter salary');
        let e1={id:id,name:name,salary:salary};
        s.add(e1);
        alert('deatils'+ i +'added successfully');
    }
}

function showAll(){
    s.forEach((e)=>document.write("<br>"+e.id+" "+e.name+" "+e.salary));
}

function remove(eid){
    let s1=Array.from(s);
    s1.map((e,i)=>{
        if (e.id==eid){
            s1.splice(i,1);
            alert('deleted...')
        }
    })

    s=new Set(s1);
}