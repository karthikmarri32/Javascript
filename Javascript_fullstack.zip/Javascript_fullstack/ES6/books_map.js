let b=new Map();
function add1(n){
    for(let i=1;i<=n;i++){
        let book=prompt("enter your book");
        b.set(i,book);
    }
}

function showBooks(){
    b.forEach((k)=>document.write(k+"<br>"))
}