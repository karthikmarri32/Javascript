let products=[];
function add(n){
    for (let i=1;i<=n;i++){
        let p_id=prompt('enter id');
        let p_name=prompt('enter name');
        let p_price=prompt('enter price');
        let p_description=prompt('enter description');
        let pro={id:p_id,name:p_name,price:p_price,description:p_description};
        let jpro=JSON.stringify(pro);
        products.push(jpro);
    }
}

function showAll(){
    for (let pd of products){
        let p=JSON.parse(pd);
        document.write("<br>"+p.id+" "+p.name+" "+p.price+" "+p.description);
    }
}