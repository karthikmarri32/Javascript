let s=new Set();
function addSkill(n){
    for (let i=1;i<=n;i++){
        let skill=prompt('add a skill');
        s.add(skill);
    }
}

function showAllSkills(){
    alert("set length: "+s.size)
    let s1=Array.from(s);
    s1.sort();
    s1.forEach((sk)=>document.write("<br>"+sk));
    }

    function deleteSkill(){
        let ele=prompt('enter the value to delete');
        s.delete(ele);
    }

function search(){
    let ele=prompt('enter element to search');
    if (s.has(ele)){
        alert(ele+'skill is available')
    }else{
        alert(ele+'skill is not available');
    }
}

