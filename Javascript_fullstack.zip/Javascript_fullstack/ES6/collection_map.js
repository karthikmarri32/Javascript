let m=new Map();
function add(n){
    for(let i=1;i<=n;i++){
        let skill=prompt("enter your skill");
        m.set(i,skill);
    }
}

function showSkills(){
    m.forEach((k)=>document.write(k+"<br>"))
}