let emap=new Map();
function addEmp(n){
    for(let i=1;i<=n;i++){
        let eid=prompt('enter id');
        let ename=prompt('enter name');
        let esalary=prompt('enter salary');
        let e1={id:eid,name:ename,salary:esalary};
        emap.set(e1.id,e1);
    }
}

function showAll(){
    emap.forEach((e)=>document.write("<br>"+e.id+" "+e.name+" "+e.salary));
}

function search(empid){
    if (emap.has(empid)){
        let e=emap.get(empid)
        document.write(e.id+" "+e.name+" "+e.salary);
    }else{
        alert('not found')
    }
}

function deleteEmp(empid){
    if(emap.has(empid)){
        emap.delete(empid)
        alert('deleted....')
    }else{
        alert('not found')
    }
}

