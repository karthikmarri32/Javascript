let product={
    id:'',
    name:'',
    price:'',
    description:'',
    display(){
        document.write(this.id+" "+this.name+" "+this.price+" "+this.description);
    }
}

let product1={
    productType:'',
    display(){
        document.write(this.id+" "+this.name+" "+this.price+" "+this.description+" "+this.productType+"<br>");
    }
}

product1.__proto__=product;
product1.id='1';
product1.name='MI';
product1.price='7000';
product1.description='Smartphone';
product1.productType='Mobile'
product1.display();

let product2={
    productCategory:'',
    display(){
        document.write(this.id+" "+this.name+" "+this.price+" "+this.description+" "+this.productType+" "+this.productCategory);
    }
}

product2.__proto__=product1;
product2.id='1';
product2.name='MI';
product2.price='7000';
product2.description='Smartphone';
product2.productType='Mobile';
product2.productCategory='Electronics'
product2.display();


