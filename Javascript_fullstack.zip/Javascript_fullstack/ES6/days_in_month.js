let dim=new Map();
dim.set('jan','31 days');
dim.set('feb','28 days');
dim.set('mar','31 days');
dim.set('apr','30 days');

function findDaysInMonth(month){
    document.write(dim.get(month));
}
findDaysInMonth('apr');