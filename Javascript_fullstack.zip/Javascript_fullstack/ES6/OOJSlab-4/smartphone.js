class SmartPhone extends Mobile{
    type='';
    constructor(id,name,cost,type){
        super(id,name,cost);
        this.type=type;
    }
    printAll(){
        document.write("<br>"+this.id+" "+this.name+" "+this.cost+" "+this.type);
    }
}
let s1=new SmartPhone(21,'MI',15000,'Smart');
s1.printAll();