class BasicPhone extends Mobile{
    type='';
    constructor(id,name,cost,type){
        super(id,name,cost);
        this.type=type;
    }
    printAll(){
        document.write("<br>"+this.id+" "+this.name+" "+this.cost+" "+this.type);
    }
}
let b1=new BasicPhone(21,'Nokia',3000,'Basic');
b1.printAll();