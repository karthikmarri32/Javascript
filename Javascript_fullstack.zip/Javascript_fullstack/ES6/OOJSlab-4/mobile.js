class Mobile {
    id=0;
    name='';
    cost=0;
    constructor(id,name,cost){
        this.id=id;
        this.name=name;
        this.cost=cost;
    }
    printAll(){
        document.write(this.id+" "+this.name+" "+this.cost);
    }
}