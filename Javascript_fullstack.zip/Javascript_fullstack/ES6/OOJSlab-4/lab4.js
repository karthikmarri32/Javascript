class Products{
    id=0;
    name='';
    price=0;
    description='';
    constructor(id,name,price,description){
        this.id=id;
        this.name=name;
        this.price=price;
        this.description=description;
    }
}
class Product1 extends Products{
    productType='';
    constructor(id,name,price,description,productType){
        super(id,name,price,description);
        this.productType=productType;
    }
    printProduct1Details(){
        document.write(this.id+" "+this.name+" "+this.price+" "+this.description+" "+this.productType+"<br>");
    }
}

let p=new Product1(777,'MI',20000,'mobile','Electronics');
p.printProduct1Details();

class Product2 extends Products{
    productCategory='';
    constructor(id,name,price,description,productCategory){
        super(id,name,price,description);
        this.productCategory=productCategory;
    }
    printProduct2Details(){
        document.write(this.id+" "+this.name+" "+this.price+" "+this.description+" "+this.productCategory);
    }
}

let p2=new Product2(777,'MI',20000,'mobile','AA');
p2.printProduct2Details();


