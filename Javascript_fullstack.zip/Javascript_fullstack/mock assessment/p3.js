// let b=new Set();
// function addBook(n){
//     for (let i=1;i<=n;i++){
//         let book=prompt('add a book');
//         b.add(book);
//     }
// }

// function showAllBooks(){
//     alert("set length: "+b.size)
//     let b1=Array.from(b);
//     b1.sort();
//     b1.forEach((book)=>document.write("<br>"+book));
//     }

// function search(){
//     let ele=prompt('enter element to search');
//     if (b.has(ele)){
//         alert(ele+'book is available')
//     }else{
//         alert(ele+'book is not available');
//     }
// }

// function deleteBook(){
//     let ele=prompt('enter the value to delete');
//     b.delete(ele);
// }


let bmap=new Map();
function addBook(n){
    for(let i=1;i<=n;i++){
        let bid=prompt('enter id');
        let bname=prompt('enter name');
        let b1={id:bid,name:bname};
        bmap.set(b1.id,b1);
    }
}

function showAll(){
    bmap.forEach((b)=>document.write("<br>"+b.id+" "+b.name));
}

function search(bookid){
    if (bmap.has(bookid)){
        let b=bmap.get(bookid)
        document.write(b.id+" "+b.name);
    }else{
        alert('not found')
    }
}

function deleteBook(bookid){
    if(bmap.has(bookid)){
        bmap.delete(bookid)
        alert('deleted....')
    }else{
        alert('not found')
    }
}



