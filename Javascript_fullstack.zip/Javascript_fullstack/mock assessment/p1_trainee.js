class Trainee extends Employee{
    transportallowances=0;
    constructor(id,name,salary,transportallowances){
        super(id,name,salary);
        this.transportallowances=transportallowances;
    }
    transportAllowances(){
        let ta = (this.salary*this.transportallowances)/100;
        document.write(this.id + " " + this.name + " " + this.salary + " " + ta)
    }
}
let tr=new Trainee(1,'Karthik',30000,10);
tr.transportAllowances();
