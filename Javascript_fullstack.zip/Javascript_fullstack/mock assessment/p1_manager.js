class Manager extends Employee{
    transportallowances=0;
    constructor(id,name,salary,transportallowances){
        super(id,name,salary);
        this.transportallowances=transportallowances;
    }
    transportAllowances(){
        let ta = (this.salary*this.transportallowances)/100;
        document.write("<br>"+this.id + " " + this.name + " " + this.salary + " " + ta)
    }
}
let t2=new Manager(101,'Nag',300000,15);
t2.transportAllowances();