class Employee {
    id=0;
    name='';
    salary=0;
    constructor(id,name,salary){
        this.id=id;
        this.name=name;
        this.salary=salary;
    }
}