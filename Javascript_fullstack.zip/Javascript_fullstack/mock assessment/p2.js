function stateDetails(){
    let t=document.getElementById('state').value;
    let AndhraPradesh=['Kurnool','Guntur','Visakhapatnam','Nellore']
    let Telangana=['Hyderabad','Warangal','Nizamabad']
    let c=document.getElementById('city');
    if(t=='AP'){
        c.options.length=0;
        for(let i=0; i<AndhraPradesh.length;i++){
            let opt=document.createElement('option');
            opt.text=AndhraPradesh[i];
            opt.value=AndhraPradesh[i];
            c.add(opt);
        }
    }else{
        c.options.length=0;
        for(let i=0; i<Telangana.length;i++){
            let opt=document.createElement('option');
            opt.text=Telangana[i];
            opt.value=Telangana[i];
            c.add(opt);
        }
    }
}

function calculate(eve)
{
    eve.preventDefault();
    let c=document.getElementById('city').value;
    let n=document.getElementById('uemp').value;
    if (c =='Kurnool'){
            document.getElementById('ta').value=(n*2000);
    }
    if (c =='Guntur'){
        document.getElementById('ta').value=(n*2000);
    }
    if (c =='Visakhapatnam'){
        document.getElementById('ta').value=(n*2000);
    }
    if (c =='Nellore'){
        document.getElementById('ta').value=(n*2000);
    }
    if (c =='Hyderabad'){
        document.getElementById('ta').value=(n*1500);
    }
    if (c =='Warangal'){
        document.getElementById('ta').value=(n*1500);
    }
    if (c =='Nizamabad'){
        document.getElementById('ta').value=(n*1500);
    }
}